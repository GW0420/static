# 测试用例
> 打开 dev-tools 面板查看请求

1. [stackoverflow 打开 test `https://patrickhlauke.github.io/recaptcha/ `](https://stackoverflow.com/tags/socat/hot?filter=all)
2. [Google reCAPTCHA  打开 test `https://patrickhlauke.github.io/recaptcha/ `](https://patrickhlauke.github.io/recaptcha/)
3. [`pub.dev`域名下`fonts.googleapis.com`无法地址重定向； 打开 test](https://pub.dev/)
